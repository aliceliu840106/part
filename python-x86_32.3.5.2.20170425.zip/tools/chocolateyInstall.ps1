﻿'This package is deprecated. 
Please install python with -ForceX86 parameter and make sure
useRememberedArgumentsForUpgrades feature is on' | Write-Host
throw 'Deprecated package'